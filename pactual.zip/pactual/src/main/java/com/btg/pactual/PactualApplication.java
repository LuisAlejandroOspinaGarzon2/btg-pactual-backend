package com.btg.pactual;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PactualApplication {

	public static void main(String[] args) {
		SpringApplication.run(PactualApplication.class, args);
	}

}
